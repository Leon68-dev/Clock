//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Clockvcmfc.rc
//
#define IDD_CLOCK_VC_MFC_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDD_ABOUTBOX                    129
#define IDD_CALENDAR_DLG                131
#define IDD_SHUTDOWN_DLG                133
#define IDD_SETUP_DLG                   135
#define IDR_MENU_CONTEXT                138
#define IDB_BITMAP1                     139
#define IDD_WORLD_MAP                   141
#define IDR_WORLD_MAP                   143
#define IDC_STATIC_IMG                  1000
#define IDC_STATIC_VER                  1001
#define IDC_STATIC_COPY                 1002
#define IDC_STATIC_WINVER               1003
#define IDC_STATIC_MEM                  1004
#define IDC_STATIC_TOTAL_MEM            1004
#define IDC_MONTHCALENDAR1              1005
#define IDC_TIME_SHUTDOWN               1007
#define IDC_CHK_SHUTDOWN_WORK           1008
#define IDC_CHK_SLEEP                   1009
#define IDC_SLIDER_OPACITY              1010
#define IDC_CHK_GMT                     1011
#define IDC_CHK_DAY                     1012
#define IDC_CHK_DATE                    1013
#define IDC_CHK_MOVING                  1014
#define IDC_CHK_TRANSPARENT             1015
#define IDC_CHK_TOPMOST                 1016
#define IDC_CHK_BORDER                  1017
#define IDC_CHK_SOUND                   1018
#define IDC_CHK_SOUND_HOURS             1018
#define IDC_STATIC_AVAIL_MEM            1019
#define IDC_CHK_SMOOTH                  1020
#define IDC_CHK_SOUND_TICKTACK          1021
#define IDC_CHK_SOUND_1530              1023
#define IDC_CHK_24HOURS                 1024
#define IDC_CHK_DIGITAL                 1025
#define IDC_CHK_SYSMON                  1026
#define IDC_CHK_CALENDAR                1027
#define IDC_CHK_PING                    1028
#define IDC_EDT_PING_ADR                1029
#define IDC_CHK_WEATHER                 1030
#define IDC_EDT_WEATHER_CITY            1031
#define IDC_EDT_WEATHER_KEY             1032
#define IDC_BTN_LINK                    1034
#define IDC_CHECK1                      1035
#define IDC_CHK_SECONDS                 1035
#define ID_MENU_SETUP                   32771
#define ID_MENU_ABOUT                   32772
#define ID_MENU_CALENDAR                32773
#define ID_MENU_SHUTDOWN                32774
#define ID_MENU_EXIT                    32775
#define ID_CLOCKPOPUP_HIDE              32776
#define ID_MENU_HIDE                    32777
#define ID_CLOCKPOPUP_STARTPOSITION     32778
#define ID_MENU_STARTPOSITION           32779
#define ID_Menu                         32780
#define ID_TRAYPOPUP_SETUP              32781
#define ID_TRAYPOPUP_HIDE               32782
#define ID_Menu32783                    32783
#define ID_CLOCKPOPUP_WOFLDMAP          32784
#define ID_CLOCKPOPUP_WORLDMAP          32785
#define ID_MENU_WORLDMAP                32786

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        144
#define _APS_NEXT_COMMAND_VALUE         32787
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
